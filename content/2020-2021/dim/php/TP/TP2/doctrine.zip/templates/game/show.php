<div class="row">
    <div class="col-md-4">
        <img class="img-responsive" src="<?= $game["image"]; ?>"/>
    </div>
    <div class="col-md-8">
        <h1><?= $game["name"]; ?></h1>

        </table>
    </div>
</div>
